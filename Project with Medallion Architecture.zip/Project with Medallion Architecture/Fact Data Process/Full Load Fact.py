# Databricks notebook source
from pyspark.sql import functions as F
from delta.tables import DeltaTable

# COMMAND ----------

# DBTITLE 1,Cell 2
bronze_schema = "bronze"
silver_schema = "silver"
gold_schema = "gold"

print(bronze_schema, silver_schema, gold_schema)

# COMMAND ----------

# DBTITLE 1,Cell 3
dbutils.widgets.text("catalog", "fmcg", "Catalog")
dbutils.widgets.text("data_source", "orders", "Data Source")

catalog = dbutils.widgets.get("catalog")
data_source = dbutils.widgets.get("data_source")

base_path = "/Volumes/fmcg/bronze/child_company/orders/"
landing_path = f"{base_path}/landing/"
processed_path = f"{base_path}/processed/"

print("Base Path: ", base_path)
print("Landing Path: ", landing_path)
print("Processed Path: ", processed_path)

bronze_table = f"{catalog}.{bronze_schema}.{data_source}"
silver_table = f"{catalog}.{silver_schema}.{data_source}"
gold_table = f"{catalog}.{gold_schema}.sb_fact_{data_source}"

# COMMAND ----------

# MAGIC %md
# MAGIC # Bronze

# COMMAND ----------

# DBTITLE 1,Cell 5
df = spark.read.options(header=True, inferSchema=True).csv(f"{landing_path}/*.csv").withColumn("read_timestamp", F.current_timestamp()).select("*", "_metadata.file_name", "_metadata.file_size")

print("Total Rows: ", df.count())
df.show(5)

# COMMAND ----------

df.write\
 .format("delta") \
 .option("delta.enableChangeDataFeed", "true") \
 .mode("append") \
 .saveAsTable(bronze_table)

# COMMAND ----------

# MAGIC %md
# MAGIC # Moving  files from source to processed folder

# COMMAND ----------

files= dbutils.fs.ls(landing_path)
for file_info in files:
  dbutils.fs.mv(file_info.path, f"{processed_path}/{file_info.name}", True)

# COMMAND ----------

# MAGIC %md
# MAGIC # Silver

# COMMAND ----------

df_orders = spark.sql(f"SELECT * FROM {bronze_table}")
df_orders.show(2)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Keep only rows where order_qty is present

# COMMAND ----------

df_orders= df_orders.filter(F.col("order_qty").isNotNull())
df_orders.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Clean customer_id → keep numeric, else set to 999999

# COMMAND ----------

df_orders= df_orders.withColumn(
  "customer_id", 
  F.when(F.col("customer_id").rlike("^[0-9]+$"), F.col("customer_id"))
  .otherwise("999999").cast("string")
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Remove weekday name from the date text "Tuesday, July 01, 2025" → "July 01, 2025"

# COMMAND ----------

df_orders= df_orders.withColumn(
  "Order_placement_date",
  F.regexp_replace(F.col("order_placement_date"), r"^[A-Za-z]+,\s*", "")
)

df_orders.select("Order_placement_date").show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Parse order_placement_date using multiple possible formats

# COMMAND ----------

df_orders = df_orders.withColumn(
    "order_placement_date",
    F.coalesce(
        F.try_to_date("order_placement_date", "yyyy/MM/dd"),
        F.try_to_date("order_placement_date", "dd-MM-yyyy"),
        F.try_to_date("order_placement_date", "dd/MM/yyyy"),
        F.try_to_date("order_placement_date", "MMMM dd, yyyy"),
    )
)
df_orders.select("Order_placement_date").show()


# COMMAND ----------

# 5. Drop duplicates
df_orders = df_orders.dropDuplicates(["order_id", "order_placement_date", "customer_id", "product_id", "order_qty"])

# 5. convert product id to string
df_orders = df_orders.withColumn('product_id', F.col('product_id').cast('string'))

# COMMAND ----------

df_orders.agg(
    F.min("order_placement_date").alias("min_date"),
    F.max("order_placement_date").alias("max_date")
).show()

# COMMAND ----------

# MAGIC %md
# MAGIC # Join With Products

# COMMAND ----------

df_products = spark.table("fmcg.silver.product")
df_joined = df_orders.join(df_products, on="product_id", how="inner").select(df_orders["*"], df_products["product_code"])

df_joined.show(5)

# COMMAND ----------

# If table does not exist → create table
if not spark.catalog.tableExists(silver_table):

    (df_joined.write
        .format("delta")
        .option("delta.enableChangeDataFeed", "true")
        .option("mergeSchema", "true")
        .mode("overwrite")
        .saveAsTable(silver_table)
    )

# If table exists → merge data
else:
    silver_delta = DeltaTable.forName(spark, silver_table)

    merge_condition = """
        silver.order_placement_date = bronze.order_placement_date
        AND silver.order_id = bronze.order_id
        AND silver.product_code = bronze.product_code
        AND silver.customer_id = bronze.customer_id
    """
    (silver_delta.alias("silver")
        .merge(df_joined.alias("bronze"), merge_condition)
        .whenMatchedUpdateAll()
        .whenNotMatchedInsertAll()
        .execute()
    )

# COMMAND ----------

# MAGIC %md
# MAGIC # Gold

# COMMAND ----------

df_gold = spark.sql(f"SELECT order_id, order_placement_date as date, customer_id as customer_code, product_code, product_id,\
   order_qty as sold_quantity FROM {silver_table};")

df_gold.show(2)

# COMMAND ----------

if not spark.catalog.tableExists(gold_table):
    print("Creating new table")
    (df_gold.write
        .format("delta")
        .mode("overwrite")
        .option("mergeSchema", "true")
        .saveAsTable(gold_table)
    )

else:
    merge_condition = """
        source.date = gold.date AND
        source.order_id = gold.order_id AND
        source.product_code = gold.product_code AND
        source.customer_code = gold.customer_code
    """
    (DeltaTable.forName(spark, gold_table)
        .alias("source")
        .merge(df_gold.alias("gold"), merge_condition)
        .whenMatchedUpdateAll()
        .whenNotMatchedInsertAll()
        .execute()
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ### Merging with Parent company

# COMMAND ----------

df_child = spark.sql(f"SELECT date, product_code, customer_code, sold_quantity FROM {gold_table}")
df_child.show(10)

# COMMAND ----------

df_child.count()

# COMMAND ----------

df_monthly = (
    df_child
    # 1. Get month start date
    .withColumn("month_start", F.trunc("date", "MM"))

    # 2. Group at monthly grain by month_start + product_code + customer_code
    .groupBy("month_start", "product_code", "customer_code")
    .agg(F.sum("sold_quantity").alias("sold_quantity"))

    # 3. Rename month_start back to `date` to match your target schema
    .withColumnRenamed("month_start", "date")
)
df_monthly.show()

# COMMAND ----------

df_monthly.count()

# COMMAND ----------

merge_condition = """
    parent_gold.date = child_gold.date AND
    parent_gold.product_code = child_gold.product_code AND
    parent_gold.customer_code = child_gold.customer_code
"""

(DeltaTable.forName(spark, f"{catalog}.{gold_schema}.fact_orders")
    .alias("parent_gold")
    .merge(df_monthly.alias("child_gold"), merge_condition)
    .whenMatchedUpdateAll()
    .whenNotMatchedInsertAll()
    .execute()
)

# COMMAND ----------

