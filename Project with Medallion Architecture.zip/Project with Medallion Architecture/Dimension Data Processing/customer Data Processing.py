# Databricks notebook source
# DBTITLE 1,Cell 1: corrected imports
from pyspark.sql import functions as F
from delta.tables import DeltaTable

# COMMAND ----------

# DBTITLE 1,Cell 2
# MAGIC %run "/Workspace/Users/shaoncontact@gmail.com/project101/Setup Folder/utils"

# COMMAND ----------

# DBTITLE 1,Cell 3
dbutils.widgets.text("catalog", "fmcg", "catalog")
dbutils.widgets.text("data_source", "customer", "Data Source")

catalog = dbutils.widgets.get("catalog")
data_source = dbutils.widgets.get("data_source")

# base_path= f's3://sportsbar-final/{data_source}/*.csv' #it will work if i take the data from AWS
# base_path= f'fmcg.bronze.customers' # if customer is in a folder thats why use ___f___
base_path = "/Volumes/fmcg/bronze/child_company/customers/customers.csv"
print(base_path)

# COMMAND ----------

# MAGIC %md
# MAGIC # Bronze

# COMMAND ----------

# DBTITLE 1,Cell 5
df = (
    spark.read.format("csv")
    .option("header", "true")
    .option("inferSchema", "true")
    .load(base_path)
    .withColumn("read_timestamp", F.current_timestamp())
    .select("*", "_metadata.file_name", "_metadata.file_size")
)

# COMMAND ----------

df.printSchema()

# COMMAND ----------

display(df.limit(10))

# COMMAND ----------

# DBTITLE 1,Cell 8
df.write\
 .format("delta") \
 .option("delta.enableChangeDataFeed", "true") \
 .mode("overwrite") \
 .saveAsTable(f"{catalog}.bronze.{data_source}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Silver

# COMMAND ----------

df_bronze = spark.sql(f"SELECT * FROM {catalog}.{bronze_schema}.{data_source};")
df_bronze.show(10)

# COMMAND ----------

df_bronze.printSchema()

# COMMAND ----------

df_duplicate= df_bronze.groupby("customer_id").count().filter(F.col("count")>1)
display(df_duplicate)

# COMMAND ----------

print('Row Before duplicate droped', df_bronze.count())
df_silver= df_bronze.dropDuplicates(["customer_id"])
print('Rows after duplicates dropped: ', df_silver.count())

# COMMAND ----------

display(df_silver.filter(F.col("customer_name") != F.trim(F.col("customer_name"))))

# COMMAND ----------

df_silver= df_silver.withColumn("customer_name", F.trim(F.col("customer_name")))
display(df_silver.filter(F.col("customer_name") != F.trim(F.col("customer_name"))))

# COMMAND ----------

df_silver.select('city') .distinct().show()

# COMMAND ----------

# DBTITLE 1,Cell 17
city_mapping = {
    'Bengaluruu':'Bengaluru','Bengalore':'Bengaluru',
    'Hyderabadd':'Hyderabad','Hyderbad':'Hyderabad',
    'NewDelhi':'New Delhi','NewDheli':'New Delhi','NewDelhee':'New Delhi'
}


allowed = ["Bengaluru", "Hyderabad", "New Delhi"]

df_silver = (df_silver.replace(city_mapping, subset=["city"])
    .withColumn("city", F.when(F.col("city").isNull(), None)
         .when(F.col("city").isin(allowed), F.col("city")).otherwise(None) ))

# COMMAND ----------

df_silver.select('city').distinct().show()

# COMMAND ----------

df_silver.select("customer_name").distinct().show()

# COMMAND ----------

df_silver= df_silver.withColumn("customer_name", F.when(F.col("customer_name").isNull(), None)
                                .otherwise(F.initcap("customer_name")))

df_silver.select("customer_name").distinct().show()

# COMMAND ----------

# DBTITLE 1,Cell 21
df_silver.filter(F.col("city").isNull()).show(truncate=False)

# COMMAND ----------

# DBTITLE 1,Cell 22
null_customer_names = ['Sprintx Nutrition', 'Zenathlete Foods', 'Primefuel Nutrition', 'Recovery Lane']
df_silver.filter(F.col("customer_name").isin(null_customer_names)).show(truncate=False)

# COMMAND ----------

# DBTITLE 1,Cell 23
customer_city_fix = {
    # Sprintx Nutrition
    789403: "New Delhi",
    # Zenathlete Foods
    789420: "Bengaluru",
    # Primefuel Nutrition
    789521: "Hyderabad",
    # Recovery Lane
    789603: "Hyderabad"
}

df_fix = spark.createDataFrame(
    [(k, v) for k, v in customer_city_fix.items()],
    ["customer_id", "fixed_city"]
)

display(df_fix)


# COMMAND ----------

df_silver = (
    df_silver
    .join(df_fix, "customer_id", "left")
    .withColumn(
        "city",
        F.coalesce("city", "fixed_city")   # Replace null with fixed city
    )
    .drop("fixed_city"))


null_customer_names = ['Sprintx Nutrition', 'Zenathlete Foods', 'Primefuel Nutrition', 'Recovery Lane']
df_silver.filter(F.col("customer_name").isin(null_customer_names)).show(truncate=False)

# COMMAND ----------

df_silver = df_silver.withColumn("customer_id", F.col("customer_id").cast("string"))
print(df_silver.printSchema())

# COMMAND ----------

# MAGIC %md
# MAGIC # Standardizing Customer Attributes to Match Parent Company Data Model

# COMMAND ----------

# DBTITLE 1,Cell 27
df_silver= (df_silver.withColumn("customer", F.concat_ws("-", "customer_name", F.coalesce(F.col("city"), F.lit("Unknown")))
            )
    .withColumn("market", F.lit("India"))
    .withColumn("platform", F.lit("Sports Bar"))
    .withColumn("channel", F.lit("Acquisition"))
)

# COMMAND ----------

display(df_silver.limit(5))

# COMMAND ----------

df_silver.write\
 .format("delta") \
 .option("delta.enableChangeDataFeed", "true") \
 .option("mergeSchema", "true") \
 .mode("overwrite") \
 .saveAsTable(f"{catalog}.{silver_schema}.{data_source}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Gold

# COMMAND ----------

df_silver= spark.sql(f"select * from {catalog}.{silver_schema}.{data_source};")

df_gold= df_silver.select("customer_id", "customer_name", "city", "customer", "market", "platform", "channel")

# COMMAND ----------

df_gold.write\
 .format("delta") \
 .option("delta.enableChangeDataFeed", "true") \
 .mode("overwrite") \
 .saveAsTable(f"{catalog}.{gold_schema}.sb_dim_{data_source}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Merging Data source with Parent

# COMMAND ----------

delta_table = DeltaTable.forName(spark, "fmcg.gold.dim_customers")
df_child_customers = spark.table("fmcg.gold.sb_dim_customer").select(
    F.col("customer_id").alias("customer_code"),
    "customer",
    "market",
    "platform",
    "channel"
)

# COMMAND ----------

delta_table.alias("target").merge(
    source=df_child_customers.alias("source"),
    condition="target.customer_code = source.customer_code"
).whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()

# COMMAND ----------

display(spark.sql("SHOW TABLES IN fmcg.gold"))

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC