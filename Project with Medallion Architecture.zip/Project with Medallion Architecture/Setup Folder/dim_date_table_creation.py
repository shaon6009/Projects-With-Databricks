# Databricks notebook source
# DBTITLE 1,Cell 1
from pyspark.sql import functions as F

# COMMAND ----------

start_date = "2024-01-01"
end_date   = "2025-12-01"

# COMMAND ----------

# DBTITLE 1,Cell 3
df = spark.sql(f"""
    SELECT EXPLODE(
        SEQUENCE(
            TO_DATE('{start_date}'),
            TO_DATE('{end_date}'),
            INTERVAL 1 MONTH
        )
    ) AS Month_Start_Date
""")

# COMMAND ----------

df = (
    df
    .withColumn("date_key", F.date_format("month_start_date", "yyyyMM").cast("int"))
    .withColumn("year", F.year("month_start_date"))
    .withColumn("month_name", F.date_format("month_start_date", "MMMM"))
    .withColumn("month_short_name", F.date_format("month_start_date", "MMM"))
    .withColumn("quarter", F.concat(F.lit("Q"), F.quarter("month_start_date")))
    .withColumn("year_quarter", F.concat(F.col("year"), F.lit("-Q"), F.quarter("month_start_date")))
)
df.display()

# COMMAND ----------

# DBTITLE 1,Cell 5
df.write.mode("overwrite").format("delta").saveAsTable("fmcg.gold.dim_date")